package br.com.fiap.CrudSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
